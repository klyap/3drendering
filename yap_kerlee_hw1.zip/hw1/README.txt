To compile:

 > make
 > ./wireframe filename.txt | display -
       OR
   ./wireframe filename.txt | convert - my_image_name.png


Image resolution:
Specified in wireframe.h
