To compile:

 > make
 > ./shaded_renderer [scene_description_file.txt] [xres] [yres] [mode]
	OR
   ./shaded_renderer [scene_description_file.txt] [xres] [yres] [mode] | convert - my_image_name.png


xres and yres are integers that specify the xx and yy resolutions of the output image
mode is either 0 or 1
