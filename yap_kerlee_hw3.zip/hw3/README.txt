To compile:

 > make
 > ./opengl_shader [scene_description_file.txt] [xres] [yres]

