*** CS 171 HW 4 ***

Instructions on how to make:

    - Go to the root directory of the project (the directory that includes the Makefile)
    - make all

Instructions on how to run:

    - call "bin/shader" from the root directory of the project


Part 2
1. mouse is protected so that only syncMouseCoords() is the only function that can change the mouse coordinates. 
syncMouseCoords()'s purpose is to modify the mouse object. It updates the mouse's pixel coordinates with the camera coordinates.
