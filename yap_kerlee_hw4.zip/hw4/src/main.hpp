#ifndef MAIN_HPP
#define MAIN_HPP

#include "common.hpp"

#endif
